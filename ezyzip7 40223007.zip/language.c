# include <stdio.h>
# include <string.h>
# include <ctype.h>

int main ()
{
    int n,i,N,j=0,k=0;//elahe bbaaei
    char vasteh;//40223007
    
    printf("please enter a number\n");
    scanf("%d",&n);

    char language1 [n][50]={};
    char language2 [n][50]={};
     
    for(i=0;i<n;i++)
    {
        printf("pleaase enter words\n");
        scanf("%s %s",&language1[i],&language2[i]);
    }

    char first_senteces[50]={};
    char senteces[50]={};
    char word[50][50]={};

    printf("plese enter  sentences (in language 1)\n");

    getchar();
 
    for(i=0;i<50;i++)
    {
        scanf("%c",&first_senteces[i]); 
        if(first_senteces[i]=='\n')
        {
            first_senteces[i]='\0';
            break;
        }
    }

    N=strlen(first_senteces);
     
    if (toupper(language1[0][0])==language1[0][0])//leeters are capital
    {    
        for(i=0;i<N;i++)
            senteces[i]=toupper(first_senteces[i]);  
    }
    if (tolower(language1[0][0])==language1[0][0])//letter are lower
    {  
        for(i=0;i<N;i++)
            senteces[i]=tolower(first_senteces[i]);   
    }

    for(i=0;i<N;i++)
    {
         if(senteces[i]!=' ')
         {
             vasteh=senteces[i];
             word[j][k]=vasteh;
             ++k;
         }
         else if (senteces[i]==' ')
         {
             ++j;
             k=0;
         }
    }
        
    for(j=0;j<n;j++)
    {  
         for(i=0;i<n;i++) 
         {
             if (strcmp(word[j],language1[i]));
             else
             {
                 if(strlen(language1[i])>strlen(language2[i]))
                     strcpy(word[j],language2[i]);
             }
         } 
     }
    for(i=0;i<n;i++) 
         printf("%s ",word[i]);    
}